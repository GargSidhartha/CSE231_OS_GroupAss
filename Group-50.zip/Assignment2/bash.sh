#!/bin/bash
echo hellow worlf
ls
cat text.txt | grep hello | wc -l
ls -l | grep shell
gcc -o fib fib.c
./fib
